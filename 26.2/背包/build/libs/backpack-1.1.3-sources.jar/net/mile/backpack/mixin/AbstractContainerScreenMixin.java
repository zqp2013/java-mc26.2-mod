package net.mile.backpack.mixin;

import net.mile.backpack.client.TerminalOverlay;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 箱子/熔炉等所有容器界面:右侧渲染终端面板,直接存取身上的储存终端。
 * 渲染挂在 extractContents 尾部(此时 translate 矩阵已 pop,用绝对屏幕坐标);
 * 输入在头部拦截,面板区域自己消费(与原版槽位重叠时让原版优先)。
 */
@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin {

	@Shadow
	protected int leftPos;
	@Shadow
	protected int topPos;
	@Shadow
	protected int imageWidth;
	@Shadow
	protected Font font;

	@Inject(method = "extractContents", at = @At("TAIL"))
	private void backpack$renderTerminalPanel(GuiGraphicsExtractor gui, int mouseX, int mouseY,
			float partialTick, CallbackInfo ci) {
		AbstractContainerScreen<?> self = (AbstractContainerScreen<?>) (Object) this;
		TerminalOverlay.render(self, gui, this.font, this.leftPos, this.topPos, this.imageWidth,
				self.width, mouseX, mouseY);
	}

	@Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
	private void backpack$terminalPanelClick(MouseButtonEvent event, boolean doubled,
			CallbackInfoReturnable<Boolean> cir) {
		AbstractContainerScreen<?> self = (AbstractContainerScreen<?>) (Object) this;
		if (TerminalOverlay.handleClick(self, event, this.leftPos, this.topPos, this.imageWidth, self.width)) {
			cir.setReturnValue(true);
		}
	}

	@Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
	private void backpack$terminalPanelKey(KeyEvent event, CallbackInfoReturnable<Boolean> cir) {
		if (TerminalOverlay.keyPressed(event)) {
			cir.setReturnValue(true);
		}
	}

	@Inject(method = "charTyped", at = @At("HEAD"), cancellable = true)
	private void backpack$terminalPanelChar(CharacterEvent event, CallbackInfoReturnable<Boolean> cir) {
		if (TerminalOverlay.charTyped(event)) {
			cir.setReturnValue(true);
		}
	}
}
